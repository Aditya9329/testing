package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DeleteAccountPage extends BasePage {
	
	DeleteAccountPage(WebDriver driver){
		super(driver);
	}
	
	@FindBy(xpath="//h2/b[text()='Account Deleted!']")
	WebElement txt_AccountDeleted;
	
	public boolean deleteAccount()
	{
		boolean status = txt_AccountDeleted.isDisplayed();
		if(status) {
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
