package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountRegistrationPage extends BasePage {

	
	public AccountRegistrationPage(WebDriver driver)
	{
		super(driver);
	}
	
	@FindBy(xpath="//div[@class='signup-form']/h2[text()='New User Signup!']")
	WebElement istxtvisible;
	
	@FindBy(xpath="//input[@name='name']")
	WebElement txtName;
	
	@FindBy(xpath="//input[@data-qa='signup-email' and @name='email']")
	WebElement signUpEmail;
	
	@FindBy(xpath="//button[text()='Signup']")
	WebElement signupBtn;
	
	//Action methods
	public void setName(String name)
	{
		txtName.sendKeys(name);
	}
	
	public void setEmail(String email)
	{
		signUpEmail.sendKeys(email);
	}
	
	public void ClickSignUp()
	{
		signupBtn.click();
	}
	
	public boolean istxtDisplayed()
	{
		if(istxtvisible.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
