package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountCreatedPage extends BasePage {

	
	public AccountCreatedPage(WebDriver driver)
	{
		super(driver);
	}
	
	@FindBy(xpath="//h2/b[text()='Account Created!']")
	WebElement txt_accountCreatedVisible;
	
	@FindBy(xpath="//div[@class='pull-right']/a[text()='Continue']")
	WebElement btn_continue;
	
	public boolean accountCreated()
	{
		
		if(txt_accountCreatedVisible.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void ClickBtnContinue()
	{
		btn_continue.click();
	}
}
