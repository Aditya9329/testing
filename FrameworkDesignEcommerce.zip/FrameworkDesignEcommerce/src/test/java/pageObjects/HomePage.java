package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{

	
	
	public HomePage(WebDriver driver)
	{
		super(driver);
	}
	
	@FindBy(xpath="//ul/li/a[text()=' Signup / Login']")
	WebElement linkSignup;
	
	@FindBy(xpath="//ul/li/a[text()=' Logged in as ']")
	WebElement txt_logged_as;
	
	@FindBy(xpath="//ul/li/a[text()=' Delete Account']")
	WebElement deleteAccount;
	
	
	//Action Methods
	
	public void signUp()
	{
		linkSignup.click();
	}
	
	public String loggedAs()
	{
		String user = txt_logged_as.getText();
		return user;
	}
	
	public void DelAcc()
	{
		deleteAccount.click();
	}
}
