package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountInformationPage extends BasePage {

	public AccountInformationPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(xpath="//h2/b[text()='Enter Account Information']")
	WebElement txt_EnterAccountInfo;
	
	@FindBy(xpath="//input[@id='first_name']")
	WebElement txt_firstName;
	
	@FindBy(xpath="//input[@id='last_name']")
	WebElement txt_lastName;
	
	@FindBy(xpath="//input[@id='address1']")
	WebElement txt_address;
	
	@FindBy(xpath="//input[@id='state']")
	WebElement txt_state;
	
	@FindBy(xpath="//input[@id='city']")
	WebElement txt_city;
	
	
	@FindBy(xpath="//input[@id='zipcode']")
	WebElement txt_zipcode;
	
	@FindBy(xpath="//input[@id='mobile_number']")
	WebElement txt_mobile;
	
	@FindBy(xpath="//input[@id='password']")
	WebElement txt_password;
	
	@FindBy(xpath="//button[text()='Create Account']")
	WebElement btn_createAccount;
	
	public boolean AccountInfo()
	{
		if(txt_EnterAccountInfo.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	public void setfname(String fname)
	{
		txt_firstName.sendKeys(fname);
	}
	
	public void setlname(String lname)
	{
		txt_lastName.sendKeys(lname);
	}
	
	public void setAddress(String address)
	{
		txt_address.sendKeys(address);
	}
	
	public void setState(String state)
	{
		txt_state.sendKeys(state);
	}
	
	public void setCity(String city)
	{
		txt_city.sendKeys(city);
	}
	
	public void setZipcode(String zipcode)
	{
		txt_zipcode.sendKeys(zipcode);
	}
	
	
	public void setMobile(String mob)
	{
		txt_mobile.sendKeys(mob);
	
	}
	
	public void setPassword(String password)
	{
		txt_password.sendKeys(password);
	}
	
	public void clickBtnCreateAccount()
	{
		btn_createAccount.click();
	}
	
	
	
}
