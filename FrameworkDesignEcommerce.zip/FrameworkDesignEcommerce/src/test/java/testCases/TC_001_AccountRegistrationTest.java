package testCases;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pageObjects.AccountCreatedPage;
import pageObjects.AccountInformationPage;
import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;

public class TC_001_AccountRegistrationTest extends BaseClass{

	
	
	@Test
	public void verify_account_registration()
	{
		HomePage hp = new HomePage(driver);
		hp.signUp();
		
		AccountRegistrationPage arp = new AccountRegistrationPage(driver);
		boolean status = arp.istxtDisplayed();
		Assert.assertTrue(status);
		arp.setName("abcde-anm");
		arp.setEmail("anm123454@gmail.com");
		arp.ClickSignUp();
		
		AccountInformationPage aip = new AccountInformationPage(driver);
		boolean info = aip.AccountInfo();
		Assert.assertTrue(info);
		
		aip.setfname("abcd");
		aip.setlname("hello");
		aip.setAddress("ABC-10");
		aip.setCity("JBP");
		aip.setState("MP");
		aip.setMobile("2233445511");
		aip.setPassword("12345");
		aip.setZipcode("486001");
		aip.clickBtnCreateAccount();
		
		AccountCreatedPage acp = new AccountCreatedPage(driver);
		Assert.assertTrue(acp.accountCreated());
		acp.ClickBtnContinue();
	}
	
	
	
}
